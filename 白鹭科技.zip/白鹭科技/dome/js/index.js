$('html').css('font-size',($(window).width())/30+'px')
$(".cut").on({
    click:function(){
        $(".menu").toggle();
    }
})
$(window).resize(function() {
    if($(window).innerWidth()>=1174){
        $(".menu").show();
    }else{
        $(".menu").hide();
    }
    $('html').css('font-size',($(window).width())/30+'px')
});
$(".gameitem>img").on({
    mouseover:function(){
        $(this).next().slideDown();
    }
})  
$(".gameitem .gameCodeContain").on({
    mouseout:function(){
        $(this).slideUp();
    }
}) 
$(".gameitem-tow>img").on({
    mouseover:function(){
        $(this).next().slideDown();
    }
})  
$(".gameitem-tow .gameCodeContain-tow").on({
    mouseout:function(){
        $(this).slideUp();
    }
}) 

